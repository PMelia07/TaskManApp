﻿if (!Modernizr.inputtypes.date) {
    $(function () {
        $(".datefield").datepicker();
    });
}